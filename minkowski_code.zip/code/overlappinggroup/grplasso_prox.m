function h = grplasso_prox(v, proj_handles)

%GRPLASSO_PROX proximal operator for overlapping group lasso
%
% Solves
%  min_x  (1/2)|| x - v ||_2^2 + lambda * sum_{g=1}^k || x_g ||_2
% where x_g is the subvector of x corresponding to group g.
%
% Usage:
%   h = grplasso_prox(v, p, lambda, G, W);
%
% Input values:
%   v = input vector
%   proj_handles = cell array of function handles for projection
%       operators onto L_q disks of group sizes
%
% Return values:
%   xhat = estimated regression coefficients
%   iter = number of Minkowski iterations 
%

projstep = minkowski_proj(v, 0.0, proj_handles); % projection
h.xhat = v - projstep.proj; % proximity operator
h.iter = projstep.iter;

end

