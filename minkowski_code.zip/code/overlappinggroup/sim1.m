%% Simulation example 1 - overlapping group lasso proximal map

% clean up
clear;

%%% Begin: Define Simulation Parameters %%%
%B = 20; % number of simulation replicates
%B = 1;
%B = 10;
B = 30;

% (d, g) PAIRS to use:
d_list = [1000 10000 100000 1000000]; % number of predictors
g_list = [10 20 50 100]; % number of observations

% penalty strength (lambda).  At most 4 rhoscales are supported
lambda_list = [2.1]; 

% SLEP parameters
maxIter=2000;
tol=1e-12;
%%% End: Define Simulation Parameters %%%



%## Simulation Setup
% simulation bookkeeping 
R = size(lambda_list, 2); % number of rhoscales to consider
C = size(d_list, 2); % number of (d, g) combinations to consider
T = B*C; % total number of replicates (for creating seeds)
%s = 1; % initialize seed tracker
%s = 6;
s = 11;

%# create structures to store results
% one structure per method used.  within each structure, there is a
% structure for each d & g combination.  Within each d & g combination,
% there's a matrix for each rhoscale ('rs')

% determine number of columns
sim_columns = 4; % run time, # of iterations, final objective value
% parameter estimate error (vs. SLEP, Minkowski only)
for d=d_list,
    for g=g_list,
    	% convert to string 
    	dg_str=strcat('d', num2str(d), 'g', num2str(g));
        for k=1:R
            % select rhoscale to use
            lambda = lambda_list(k);
            % convert to string
            rs_str=strcat('rs', num2str(lambda));
            % remove the period
            rs_str(rs_str=='.') = [];

            % Proximal operator via SLEP algorithm
            Sim_Output_SLEP.(dg_str).(rs_str) = NaN(B, sim_columns);
        
            % Proximal operator via Minkowski projection
            Sim_Output_Minkowski.(dg_str).(rs_str) = NaN(B, sim_columns);
 	end
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%
%%% Simulation Code %%%
%%%%%%%%%%%%%%%%%%%%%%%

%%% loop over (d, g) pairs %%%
start_time = clock; % initial simulation time
for d=d_list,
    % set random seed
    seed = RandStream.create('mrg32k3a','NumStreams', T, ...
            'StreamIndices', s);
    RandStream.setGlobalStream(seed);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% Main simulation loop %%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:B
    	% sample a random input
    	v = randn(d, 1);
	for g=g_list,
    	    % convert to string (for saving results)
    	    dg_str = strcat('d', num2str(d), 'g', num2str(g));
            
	    %% Set up group indexes
	    %% 
	    a = floor(d / g); % group half-bandwidth
	    G = [];
	    W = [];
	    for j=1:g,
		G = [G rem(a*(j-1):a*(j+1)-1, d)];
		W = [W [2*a*(j-1)+1; 2*a*j; 1] ];
	    end
	    % adjust indexes for mex calls
	    % group indexes G already starts from 0
	    W(1:2,:) = W(1:2,:) - 1; % to make them start from 0
	
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%% Solve using each method                               %%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for k=1:R
                % select lambda to use
                lambda = lambda_list(k);
                % convert to string
                rs_str = strcat('rs',num2str(lambda));
                % remove the period
                rs_str(rs_str == '.') = [];

	    	% cache projection operators
	    	proj_handles = getLqDiskProjections(d, lambda, G, W);
                
                %%% compare different algorithms %%%
                %
                % SLEP
		%
		Y=zeros(length(G), 1);
		tt = cputime;
		[x_SLEP, gap, info] = overlapping(v, d, g, 0.0, lambda, ...
    			W, G, Y, maxIter, 2, tol);
		timer_SLEP = cputime - tt;

                % objective function
		obj_SLEP = grpprox_obj(x_SLEP, v, lambda, G, W);
                % number of iterations
                iters_SLEP = info(4);
                % store_output
                Sim_Output_SLEP.(dg_str).(rs_str)(i,1:3) = ...
                        [timer_SLEP, iters_SLEP, obj_SLEP];
                
		%
                % Minkowski projection
		%
		tt = cputime;
		h = grplasso_prox(v, proj_handles); 
		timer_Minkowski = cputime - tt;

                % objective function
		obj_Minkowski = grpprox_obj(h.xhat, v, lambda, G, W);
                % number of iterations
                iters_Minkowski = h.iter;
                % store_output
                Sim_Output_Minkowski.(dg_str).(rs_str)(i,1:3) = ...
                        [timer_Minkowski, iters_Minkowski, obj_Minkowski];
                Sim_Output_Minkowski.(dg_str).(rs_str)(i,4) = ...
                        norm(x_SLEP - h.xhat);
            end % loop over lambda (k)
    	    % clean up workspace
    	    clear x_SLEP gap info h 
	end % loop over group sizes (g)
	clear G W
        % display progress (every 10%)
        if (i/B)*10 == floor((i/B)*10)
            display(['d = ', num2str(d), ': ', ...
                    num2str((i/B)*100), '% finished after ', ...
                    num2str(round(etime(clock, start_time)/60)) ' minutes'])
        end
    end % loop over iteration (i)
        
        
    % save output
    savefile = strcat('sim1d', num2str(d));
    save(savefile, 'Sim_Output_Minkowski', 'Sim_Output_SLEP', 'd_list', 'g_list', 'lambda_list' );
          
    s = s + 1; % update seed index
end % loop over dimensions (d)


end_time = clock;
total_time = etime(end_time, start_time)/60; % total simulation time
display(total_time)


