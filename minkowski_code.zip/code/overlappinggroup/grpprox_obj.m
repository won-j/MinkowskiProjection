function fval = grpprox_obj(x, v, lambda, G, W)

%GRPPROX_OBJ evaluate overlapping group lasso objective function
%
% Compute
%  (1/2)|| x - v ||_2^2 + lambda * sum_g ||x_g||_2 
% where x_g is the subvector of x corresponding to group g,
% g = 1, 2, ..., groupNum=size(W, 2)
%
% Usage:
%  fval = grpprox_obj(v, lambda, G, W);
%
% Input values:
%   x, v = input vectors
%   lambda = L1 penalty strength
%   G = a row vector containing the indices of all the overlapping
%           groups G_1, G_2, ..., G_groupNum
%       Index begins from 0
%   W = a 3 x groupNum matrix
%           opts.w(1,i): the starting index of G_i in opts.G
%           opts.w(2,i): the ending index of G_i in opts.G
%           opts.w(3,i): the weight for the i-th group
%       Index begins from 0
%
% Return values:
%   cell array of function handles of length size(W, 2)
%

    k = size(W, 2);  % number of groups

    fval = 0.5 * norm(x - v, 2)^2;
    for i=1:k,
        ind = G((W(1, i) + 1):(W(2, i) + 1)) + 1; % i-th group indexes
	fval = fval + lambda * norm(x(ind), 2);
    end

end % end of function


