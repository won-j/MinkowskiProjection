function proj_handles = getLqDiskProjections(d, lambda, G, W)

%GETLQDISKPROJECTIONS projection operators for overlapping group lasso
%
% Generates function handles for computing
%  min_x  (1/2)|| x - v ||_2^2 
%  subject to ||x_g||_q  <= lambda
% where x_g is the subvector of x corresponding to group g,
% g = 1, 2, ..., groupNum=size(W, 2)
%
% Usage:
%   h = getLqDiskProjection(lambda, G, W);
%
% Input values:
%   d = dimension of the problem (number of variables)
%   lambda = L1 penalty strength
%   G = a row vector containing the indices of all the overlapping
%           groups G_1, G_2, ..., G_groupNum
%       Index begins from 0
%   W = a 3 x groupNum matrix
%           opts.w(1,i): the starting index of G_i in opts.G
%           opts.w(2,i): the ending index of G_i in opts.G
%           opts.w(3,i): the weight for the i-th group
%       Index begins from 0
%
% Return values:
%   cell array of function handles of length size(W, 2)
%

    k = size(W, 2);  % number of groups

    proj_handles = cell(1, k);
    for i=1:k,
        ind = G((W(1, i) + 1):(W(2, i) + 1)) + 1; % i-th group indexes
        g = numel(ind); % group size
        proj_handles{i} = @(y) LqDiskProjection(y(ind), d, ind, g, lambda);
    end

end % end of function

function z = LqDiskProjection(v, d, ind, g, lambda)
    z = zeros(d, 1);
    z(ind) = v - eppVector(v, [0, g], 1, g, lambda, 2.0);
end

