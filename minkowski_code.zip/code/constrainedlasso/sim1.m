%% Simulation example 1 - sum to zero constraint

% clean up
clear;

%%% Begin: Define Simulation Parameters %%%
B = 20; % number of simulation replicates

% (n,p) PAIRS to use:
n_list = [ 50 100  500 1000 2000 4000]; % number of observations
p_list = [100 500 1000 2000 4000 8000]; % number of predictors

% rho_scale values (fraction of max_rho).  At most 4 rhoscales are supported
rhoscale_list = [0.2 0.4 0.6 0.8]; % rho = rhoscale*maxrho 

% optional: specify which (n, p) pairs to use (to manually parallelize) 
%       comment out to include all
j_start = 1; % starting value for j index loop 
j_end = size(n_list, 2); % ending value for j index loop

%%% End: Define Simulation Parameters %%%



%## Simulation Setup
% simulation bookkeeping 
C = size(n_list, 2); % number of (n,p) combinations to consider
R = size(rhoscale_list, 2); % number of rhoscales to consider
T = B*C; % total number of replicates (for creating seeds)
N = T*R; % total number of estimations
s = 1 + (j_start-1)*B; % initialize seed tracker
Error_log = cell(N, 1);
e = 2; % error index tracker (starts at 2 since first row is title)
Error_log{1}= 'Error log for sim1'; % title for error log

% set j_start and j_end if not specified
if exist('j_start','var')==0
    j_start = 1;
end

if exist('j_end','var')==0
    j_end = size(n_list, 2);
end

%# create structures to store results
% one structure per method used.  within each structure, there is a
% structure for each n & p combination.  Within each n & p combination,
% there's a matrix for each rhoscale ('rs')

% determine number of columns
sim_columns = 5; % run time, # of iterations, final objective value
% obj. value from solver, parameter estimate error (vs. Gurobi)

for j=j_start:j_end
    % extract values for n \& p
    n = n_list(j);
    p = p_list(j);
    
    % convert to string 
    np_str=strcat('n', num2str(n), 'p', num2str(p));
    
    for k=1:R
        % select rhoscale to use
        rhoscale = rhoscale_list(k);
        % convert to string
        rs_str=strcat('rs', num2str(rhoscale));
        % remove the period
        rs_str(rs_str=='.') = [];
        
        % QP with gurobi
        Sim_Output_Gurobi.(np_str).(rs_str) = NaN(B, sim_columns);
        % ADMM - function handle for subproblem (default admm scale)
        Sim_Output_ADMM_fh.(np_str).(rs_str) = NaN(B, sim_columns);
        
        % Solution Path (Timing is nested within (n,p) pair and not
        % rhoscale, and doesn't need to store iterations, so 2 fewer cols)
        Sim_Output_Path.(np_str).(rs_str)=NaN(B, sim_columns - 2);
        % store timing for solution path 
        Sim_Output_Path.(np_str).timing = NaN(B, 1);

        % Proximal gradient with Minkowski projection
        Sim_Output_Proxgrad.(np_str).(rs_str) = NaN(B, sim_columns+1);
    end
    
end



%%%%%%%%%%%%%%%%%%%%%%%
%%% Simulation Code %%%
%%%%%%%%%%%%%%%%%%%%%%%

%%% loop over (n,p) pairs %%%
start_time = clock; % initial simulation time
for j=j_start:j_end
        % extract values to use
        n = n_list(j);
        p = p_list(j);
        
        % convert to string (for saving results)
        np_str = strcat('n',num2str(n),'p',num2str(p));
        
        % define true parameter vector
        % sum(beta) = 0
        beta = zeros(p,1);
        beta(1:round(p/4)) = 0;
        beta(round(p/4)+1:round(p/2)) = 1;
        beta(round(p/2)+1:round(3*p/4)) = 0;
        beta(round(3*p/4)+1:end) = -1;
        
        %## constraints housekeeping
        % equality constraints
        Aeq = ones(1,p);
        beq = 0;
        m1 = size(Aeq, 1);  % # of equality constraints
        if isempty(Aeq)
            Aeq = zeros(0,p);
            beq = zeros(0,1);
        end
        % inequality constraints
        A=[];
        b=[];
        m2 = size(A, 1);    % # inequality constraints
        if isempty(A)
            A = zeros(0,p);
            b = zeros(0,1);
        end
        % penalization index
        penidx = true(p,1);
        
        % clear previous solution
        betapath = [];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%% Main simulation loop %%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for i=1:B
            
            % set random seed
            seed=RandStream.create('mrg32k3a','NumStreams',T,...
                'StreamIndices',s);
            RandStream.setGlobalStream(seed);
            
            % generate data
            X = randn(n,p);
            y = X*beta + randn(n,1);
            
            if n < p
                % add ridge penalty
                epsilon = 1e-8;
                % create augmented data
                y = [y; zeros(p, 1)];
                X = [X; sqrt(epsilon)*eye(p)];
            end
            
            %%% Begin: Determine max_rho %%%
            % set up model for GUROBI & solve
            gmodel.obj = ones(2*p,1);
            gmodel.A = sparse([A -A; Aeq -Aeq]);
            gmodel.sense = [repmat('<', m2, 1); repmat('=', m1, 1)];
            gmodel.rhs = [b; beq];
            gmodel.lb = zeros(2*p,1);
            gparam.OutputFlag = 0;
            gresult = gurobi(gmodel, gparam);
            betapath(:, 1) = gresult.x(1:p) - gresult.x(p+1:end);
            dualpathEq = reshape(gresult.pi(m2+1:end), m1, 1);
            dualpathIneq = reshape(gresult.pi(1:m2), m2, 1);


            % initialize sets
            setActive = abs(betapath(:,1))>1e-4 | ~penidx;
            betapath(~setActive,1) = 0;
            setIneqBorder = dualpathIneq > 0;
            residIneq = A*betapath(:, 1) - b;
            
            % find the maximum rho and initialize subgradient vector
            resid = y - X*betapath(:,1);
            subgrad = X'*resid - Aeq'*dualpathEq - A'*dualpathIneq;
            subgrad(setActive) = 0;
            maxrho = max(abs(subgrad));
            %%% End: Determine max_rho %%%
            
            %%% Obtain entire solution path via path folowing algorithm %%%
            try
                tic;
                [rhopath, bhat_path] ...
                    = lsq_classopath(X, y, A, b, Aeq, beq,...
                    'qp_solver', 'matlab', 'init_method', 'lp', ...
                    'penidx', penidx, 'epsilon', 1e-8);
                timing_path = toc;
                
            catch
                Error_log{e} = strcat('Solution Path Error: j=',...
                    num2str(j),', i=',num2str(i),', s=',num2str(s));
                e=e+1;
            end
            % store timing for solution path
            Sim_Output_Path.(np_str).timing(i) = timing_path/size(rhopath, 2);
            Sim_Output_Path.(np_str).timingTotal(i) = timing_path;
            Sim_Output_Path.(np_str).nRho(i) = size(rhopath, 2);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            %%% Solve using each method, looping over rhoscale values %%%
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            for k=1:R
                % select rhoscale to use
                rhoscale = rhoscale_list(k);
                % convert to string
                rs_str = strcat('rs',num2str(rhoscale));
                % remove the period
                rs_str(rs_str == '.') = [];
                
                % set value of rho to use
                rho = rhoscale*maxrho;
                
                
                %%% compare different algorithms %%%
                
                % solution path (linear interpolation)
                % find value in rhopath closest to but less than current rho
                rho_i = max(rhopath(rho - rhopath>0));
                % extract corresponding index
                [~, idx] = min(abs(rho_i - rhopath));
                % find corresponding beta_hat vector for rho_i
                bhat_path_i = bhat_path(:,idx);
                % calculate linear slopes
                % subtract 1 from index because rhopath values decrease
                slopes = (bhat_path(:,idx-1) - bhat_path_i)/...
                    (rhopath(idx-1) - rho_i);
                % find path solution for rho via linear interpolation
                bhat_path_rho = slopes*(rho - rho_i) + bhat_path_i;
                
                % calculate objective function
                obj_path = norm(y-X*bhat_path_rho)^2/2 + ...
                    rho*sum(abs(bhat_path_rho));
                % store results
                Sim_Output_Path.(np_str).(rs_str)(i, 1) = obj_path;
                
                
                % QP with Gurobi
                try
                    % coefficient estimates
                    tic;
                    [bhat_gurobi,stats] = lsq_constrsparsereg(X, y, rho, ...
                        'method', 'qp', 'qp_solver', 'gurobi', 'Aeq', Aeq,...
                        'beq', beq, 'A', A, 'b', b);
                    timer_gurobi = toc; % estimation time
                    % objective function (manual)
                    obj_gurobi = norm(y - X*bhat_gurobi)^2/2 + ...
                        rho*sum(abs(bhat_gurobi));
                    % objective function (from fxn output)
                    obj_gurobi_fxn = y'*y/2 + stats.qp_objval;
                    % number of iterations
                    iters_gurobi = stats.qp_iters;
                    % store results (standard stuff)
                    Sim_Output_Gurobi.(np_str).(rs_str)(i,1:3)=...
                        [timer_gurobi, iters_gurobi, obj_gurobi];
                    Sim_Output_Gurobi.(np_str).(rs_str)(i, end-1:end)=...
                        [obj_gurobi_fxn, norm(bhat_gurobi)];
                catch
                    Error_log{e} = strcat('QP(Gurobi) Error: j=',...
                        num2str(j),', i=',num2str(i),', k=',num2str(k),...
                        ', s=',num2str(s));
                    e=e+1;
                end
                
                
                % parameter estimation error for path algorithm
                Sim_Output_Path.(np_str).(rs_str)(i, end) = ...
                    norm(bhat_gurobi - bhat_path_rho);
                     
                            
                % ADMM (function handle) - default ADMM scale
                try
                    tic;
                    [bhat_admm_fh,stats_admm_fh] = lsq_constrsparsereg(X, ...
                        y, rho, 'method', 'admm', 'projC', @(x) x-mean(x));
                    timer_admm_fh = toc;
                    % objective function
                    obj_admm_fh = norm(y-X*bhat_admm_fh)^2/2 + ...
                        rho*sum(abs(bhat_admm_fh));
                    % number of iterations
                    iters_admm_fh=stats_admm_fh.ADMM_iters;
                    % store_output
                    Sim_Output_ADMM_fh.(np_str).(rs_str)(i,1:3) = ...
                        [timer_admm_fh, iters_admm_fh, obj_admm_fh];
                    Sim_Output_ADMM_fh.(np_str).(rs_str)(i,end) = ...
                        norm(bhat_gurobi - bhat_admm_fh);
                catch
                    Error_log{e} = strcat('ADMM(FH) Error: j=',...
                        num2str(j),', i=',num2str(i),', k=',num2str(k),...
                        ', s=',num2str(s));
                    e=e+1;
                end
                
                % Proximal gradient through Minkowski projection
                %try
		    tic; 
		    h = classo_proxgrad(X, y, rho, @(x) mean(x)*ones(p,1), []); 
		    timer_proxgrad = toc;
                    % objective function
                    obj_proxgrad = h.optval;
                    % number of iterations
                    iters_proxgrad = length(h.inneriter);
                    % store_output
                    Sim_Output_Proxgrad.(np_str).(rs_str)(i,1:3) = ...
                        [timer_proxgrad, iters_proxgrad, obj_proxgrad];
                    Sim_Output_Proxgrad.(np_str).(rs_str)(i,4:end) = ...
                        [mean(h.inneriter), std(h.inneriter), norm(bhat_gurobi - h.xhat)];
                %catch
                %    Error_log{e} = strcat('Proxgrad Error: j=',...
                %        num2str(j),', i=',num2str(i),', k=',num2str(k),...
                %        ', s=',num2str(s));
                %    e=e+1;
                %end
                                
            end % loop over rhoscales (k)
            
            s = s + 1; % update seed index
            
            % display progress (every 10%)
            if (i/B)*10 == floor((i/B)*10)
                display(['(n, p) = (' num2str(n), ', ', num2str(p), ') ', ...
                    num2str((i/B)*100), '% finished after ', ...
                    num2str(round(etime(clock, start_time)/60)) ' minutes'])
            end
            
        end % loop over iteration (i)
        
        % clean up workspace
        clear y subgrad setActive resid penidx gresult gmodel X Aeq beq A b...
            bhat_path
        
        % save output
        savefile = strcat('sim1n',num2str(n),'p',num2str(p));
        save(savefile);
          
end % loop over (n,p) pairs (j)


end_time = clock;
total_time = etime(end_time, start_time)/60; % total simulation time
display(total_time)


