function h = minkowski_proj(x, rho, proj_handles)

%MINKOWSKI_PROJ projection onto a Minkowski sum of sets
%
% Usage:
%   h = minkowski_proj(x, rho, proj_handle);
%
% Input values:
%   x = point to project
%   rho = viscosity constant
%   proj_handle = cell array of function handles, 
%                each of which compute projection onto
%                a summand set
%
% Return values:
%   proj = projection of x onto the Minkowski sum
%   iter = number of iterations until convergence
%

%%% Global constants and defaults
MAX_ITER = 100000;
ABSTOL   = 1e-6;

% number of sets
nsets = length(proj_handles);

d = length(x);
pmat = zeros(d,nsets);

for k = 1:MAX_ITER
    pnew = pmat;
    pnew(:, 1) = proj_handles{1}((x - sum(pmat(:, 2:end), 2)) / (1 + rho) + ...
                                 rho / (1 + rho) * pmat(:,1) );
    for i = 2:nsets
	pnew(:, i) = proj_handles{i}((x - sum(pnew(:, 1:i-1), 2) - ...
                                      sum(pmat(:, i+1:end), 2)) / (1 + rho) + ...
                                     rho / (1 + rho) * pmat(:, i) );
    end
    if k > 1 && norm(vecnorm(pnew - pmat), Inf) < ABSTOL
    	pmat = pnew;
        break;
    end
    pmat = pnew;
end

proj = sum(pmat, 2);
h.proj = proj;
h.iter = k;

end

