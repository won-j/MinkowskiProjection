function h = classo_proxgrad(A, b, lambda, proj_B, proj_C)

%CLASSO_PROXGRAD conically constrained lasso with proximal gradient
%
% Solves
%  min  (1/2)|| A*x - b ||_2^2 + lambda * || x ||_1
%  subject to  B*x == 0,   C*x <= 0
%
% Usage:
%   h = classo_proxgrad(X, y, lambda, proj_A, proj_C);
%
% Input values:
%   A = data matrix
%   b = response vector
%   lambda = L1 penalty strength
%   proj_B = function handle for the projection to the orthogonal 
%           complement of the subspace {x: B*x == 0 }
%   proj_C = function handle for the projection to the polar
%           cone of the cone {x: C*x <= 0}
%
% Return values:
%   xhat  = estimated regression coefficients
%   optval  = minimized objective value
%   objvals = history of objective values
%   inneriter = history of inner Minkowski iterations per outer
%              iteration
%
% Reference
% Gaines, Kim, and Zhou, "Algorithms for Constrained Lasso", JCGS 2018. 
%
% Acknowledgment:
%   This code is based on the proximal gradient code for the plain
%   lasso at
%%   https://stanford.edu/~boyd/papers/prox_algs/lasso.html
%

%%% Global constants and defaults
MAX_ITER = 10000;
ABSTOL   = 1e-5;

sum_square = @(v) sum(v.^2);
f = @(u) 0.5*sum_square(A*u-b);
%gam = 1; % initial step size
gam = 1.0/svds(A, 1)^2; % initial step size
bet = 0.5; % backtracking rate

% cached computations for all methods
AtA = A'*A;
Atb = A'*b;
LinfBallProjection = @(y) min(max(y, -lambda), lambda);
proj_handles = {};
if isempty(proj_B) && isempty(proj_B) 
    proj_handles = {LinfBallProjection};
elseif isempty(proj_C)
    proj_handles = {LinfBallProjection, proj_B};
elseif isempty(proj_B)
    proj_handles = {LinfBallProjection, proj_C};
else
    proj_handles = {LinfBallProjection, proj_B, proj_C};
end

p = size(A, 2); % num variables
x = zeros(p, 1);
xprev = x;

for k = 1:MAX_ITER
    %while 1  % line search
        grad_x = AtA*x - Atb;
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	gstep = x - gam * grad_x;
	projstep = minkowski_proj(gstep / gam, 0.0, proj_handles);
	z = gstep - gam * projstep.proj; % proximity operator
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %    if f(z) <= f(x) + grad_x'*(z - x) + (1/(2*gam))*sum_square(z - x)
    %        break;
    %    end
    %    gam = bet*gam;
    %end
    xprev = x;
    x = z;

    h.objvals(k) = 0.5 * sum_square(A * x - b) + lambda*norm(x, 1);
    h.inneriter(k) = projstep.iter;
    if k > 1 && norm(x - xprev) < ABSTOL
        break;
    end
end

h.xhat = x;
h.optval = h.objvals(end);

end


